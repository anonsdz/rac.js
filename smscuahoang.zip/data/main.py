import os
import json
import time
from datetime import datetime, timedelta
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes
import pytz
from datetime import datetime

TOKEN = '7898378784:AAGmk8eXzvNSV6cTxUVIYANLVayZwQLk0Zo'
ADMIN_ID = [7371969470, 7371969470]

COOLDOWN_FILE = "cooldown.json"
PLAN_FILE = "plan.json"

COOLDOWN_TIME = 5

def list_admin_ids() -> list:
    admin_ids = []
    plan_data = load_json("plan.json")
    for item in plan_data:
        admin_ids.append(item["user_id"])
    return admin_ids



def load_json(file_path):
    if os.path.exists(file_path):
        with open(file_path, "r") as file:
            return json.load(file)
    return {}

def save_json(data, file_path):
    with open(file_path, "w") as file:
        json.dump(data, file)

def check_user_plan(user_id):
    plan_data = load_json(PLAN_FILE)
    if user_id not in plan_data or plan_data[user_id]["banned"]:
        return False

    expiry_date = datetime.strptime(plan_data[user_id]["expiry"], "%Y-%m-%d %H:%M:%S")
    if datetime.now() > expiry_date:
        return False

    return True

async def add_user(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if update.effective_user.id not in ADMIN_ID:
        await update.message.reply_text("Bạn Không Có Quyền Sử Dụng.")
        return

    if len(context.args) != 2:
        await update.message.reply_text("Cách Dùng: /add [id] [số ngày]")
        return

    user_id = context.args[0]
    days = int(context.args[1])
    expiry_date = datetime.now() + timedelta(days=days)

    plan_data = load_json(PLAN_FILE)
    plan_data[user_id] = {
        "expiry": expiry_date.strftime("%Y-%m-%d %H:%M:%S"),
        "banned": False
    }
    save_json(plan_data, PLAN_FILE)

    await update.message.reply_text(f"Đã Cấp Quyền Cho User <code>{user_id}</code> trong <b>{days}</b> Ngày",parse_mode='HTML')

async def ban_user(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if update.effective_user.id not in ADMIN_ID:
        await update.message.reply_text("Bạn Không Có Quyền Sử Dụng.")
        return

    if len(context.args) != 1:
        await update.message.reply_text("Cách Dùng: /ban [id]")
        return

    user_id = context.args[0]

    plan_data = load_json(PLAN_FILE)
    if user_id in plan_data:
        plan_data[user_id]["banned"] = True
        save_json(plan_data, PLAN_FILE)
        await update.message.reply_text(f"Đã ban user {user_id}.")
    else:
        await update.message.reply_text(f"User {user_id} Không Tồn Tại")

async def unban_user(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if update.effective_user.id not in ADMIN_ID:
        await update.message.reply_text("Bạn Không Có Quyền Sử Dụng.")
        return

    if len(context.args) != 1:
        await update.message.reply_text("Cách Dùng: /unban [id]")
        return

    user_id = context.args[0]

    plan_data = load_json(PLAN_FILE)
    if user_id in plan_data:
        plan_data[user_id]["banned"] = False
        save_json(plan_data, PLAN_FILE)
        await update.message.reply_text(f"Đã unban user {user_id}.")
    else:
        await update.message.reply_text(f"User {user_id} Không Tồn Tại")
#bot_enabled = True
async def vip(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user_id = str(update.effective_user.id)
    admin_id = '7371969470' 
    if not check_user_plan(user_id):        
        await update.message.reply_text("Bạn Không Có Quyền Sử Dụng Bot\nVui Lòng Liên Hệ Admin Để Mua\n\nGiá Plan\n15K: Tuần\n30K: Tháng\nVĩnh Viễn: 100K\n Liên Hệ: @NeganSSHConsole\nhoặc bạn có thể sử dụng lệnh /naptien để nạp mua plan vip tự động nhé")
        return 

    #if not bot_enabled:
 ##       await update.message.reply_text("Bot hiện đang offline. Vui lòng chờ admin bật bot lại.")
   #     return

#    cooldown_data = load_json(COOLDOWN_FILE)
 #   current_time = time.time()
#    cooldown_data = load_json(COOLDOWN_FILE)
 #   current_time = datetime.now(pytz.timezone('Asia/Ho_Chi_Minh'))
  

##  if user_id in cooldown_data and current_time.timestamp() - cooldown_data[user_id] < COOLDOWN_TIME:
  #      remaining_time = COOLDOWN_TIME - (current_time.timestamp() - cooldown_data[user_id])
   #     await   
 # if user_id in cooldown_data and current_time - cooldown_data[user_id] < COOLDOWN_TIME:
  #      remaining_time = COOLDOWN_TIME - (current_time - cooldown_data[user_id])
    cooldown_data = load_json(COOLDOWN_FILE)
    current_time = time.time()
    if user_id in cooldown_data and current_time - cooldown_data[user_id] < COOLDOWN_TIME:
        remaining_time = COOLDOWN_TIME - (current_time - cooldown_data[user_id])
        await update.message.reply_text(f"Vui Lòng Chờ {int(remaining_time)} Giây Trước Khi Sử Dụng Lần Tiếp Theo")
        return

    if len(context.args) != 2:
        await update.message.reply_text("Cách Dùng: /vip [sdt] [số lần]")
        return

    phone_number = context.args[0]
    repeat_count = context.args[1]

    if not (phone_number.isdigit() and len(phone_number) == 10):
        await update.message.reply_text("Số Điện Thoại Phải Đủ 10 Số.")
        return


    try:
        repeat_count = int(repeat_count)
        if repeat_count > 10000:
            await update.message.reply_text("Số lần tối đa là 100. Vui lòng nhập số lần nhỏ hơn hoặc bằng 100.")
            return
    except ValueError:
        await update.message.reply_text("Số lần phải là số.")
        return

#    try:
 #       repeat_count = int(repeat_count)
  #  except ValueError:
   #     await update.message.reply_text("Số Lần Phải Là Con Số.")
 #       return
#
    cooldown_data[user_id] = current_time
    save_json(cooldown_data, COOLDOWN_FILE)

    command = f"screen -dm bash -c 'timeout 1000s python3 tlc.py {phone_number} {repeat_count}'"
    os.system(command)

    await update.message.reply_text(f"Thông Tin Tấn Công\n👾Plan: <b>Vip</b>\n📞Phone: <code>{phone_number}</code>\n⚡️Số Lần:  <b>{repeat_count}</b>\n⏳Delay: <b>20s</b>\n🔗Api: <b>100</b> ( MAX )\n📎Vòng Lặp: <b>1000</b> ( Mặc Định <b>1</b> | Max <b>10000</b> )", parse_mode='HTML')
    # Gửi thông tin số điện thoại và thông tin user đến admin
 #   # Gửi thông tin số điện thoại và thông tin user đến admin
  #  formatted_time = current_time.strftime('%d/%m/%Y %H:%M:%S')
#    await 
   # user_info = update.message.from_user
    #await context.bot.send_message(admin_id, f"Ngày: {formatted_time}\n Info Spam\n@{user_info.first_name} {user_info.last_name} (ID: {user_info.id})\nPlan: Vip\nPhone: {phone_number}\nConut: {repeat_count}")
   # user_info = update.message.from_user
    #await context.bot.send_message(admin_id, f"Inf Spam SMS\nUser: @{user_info.first_name}\nID: {user_info.last_name} (ID: {user_info.id})\nPhone: {phone_number}\nConut: {repeat_count}")
    user_info = update.message.from_user
    await context.bot.send_message(admin_id, f"Inf Spam SMS\nPlan: VIP\nUser: {user_info.first_name}\nID: {user_info.last_name} (ID: {user_info.id})\nPhone: {phone_number}\nConut: {repeat_count}")







#    user_info = update.message.from_user
 #   await context.bot.send_message(admin_id, f"Người dùng {user_info.first_name} {user_info.last_name} (ID: {user_info.id}) đã sử dụng lệnh /vip với số điện thoại: {phone_number}")


bot_enabled = True
async def spam(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user_id = str(update.effective_user.id)
    admin_id = '7371969470'  # Thay 'admin_id_here' bằng id của admin
    cooldown_data = load_json(COOLDOWN_FILE)
    current_time = time.time()
    if user_id in cooldown_data and current_time - cooldown_data[user_id] < COOLDOWN_TIME:
        remaining_time = COOLDOWN_TIME - (current_time - cooldown_data[user_id])
        await update.message.reply_text(f"Vui Lòng Chờ {int(remaining_time)} Giây Trước Khi Sử Dụng.")
        return
    if not bot_enabled:
        await update.message.reply_text("Bot hiện đang offline. Vui lòng chờ admin bật bot lại.")
        return

#    if update.effective_chat.type != 'group':
  #      await update.message.reply_text("Lệnh này chỉ hoạt động trong nhóm.\n https://t.me/+fzo3QjDkxFA3ODk9")
 #       return


    if len(context.args) != 2:
        await update.message.reply_text("Cách Dùng: /spam [sdt] [số lần]")
        return

    phone_number = context.args[0]
    repeat_count = context.args[1]

    if not (phone_number.isdigit() and len(phone_number) == 10):
        await update.message.reply_text("Số Điện Thoại Phải Đủ 10 Số.")
        return


    try:
        repeat_count = int(repeat_count)
        if repeat_count > 5:
            await update.message.reply_text("Số lần tối đa là 5. Vui lòng nhập số lần nhỏ hơn hoặc bằng 5.")
            return
    except ValueError:
        await update.message.reply_text("Số lần phải là số.")
        return


  #  try:
#        repeat_count = int(repeat_count)
 #       if repeat_count > 10:
   #         await update.message.reply_text("Số lần tối đa là 10. Vui lòng nhập số lần nhỏ hơn hoặc bằng 10.")
      #      return
    ##e#xcept ValueError:
        #await update.message.reply_text("Số lần phải là số.")
 #       return
#
  #  try:
#        repeat_count = int(repeat_count)
 # #  except ValueError:
    ##    await update.message.reply_text("Số Lần Phải Là Con Số.")
  #      return
##
    cooldown_data[user_id] = current_time
    save_json(cooldown_data, COOLDOWN_FILE)

    command = f"screen -dm bash -c 'timeout 250s python3 sms.py {phone_number} {repeat_count}'"
    os.system(command)

    await update.message.reply_text(f"Thông Tin Tấn Công\n👾Plan: <b>Free</b>\n📞Phone: <code>{phone_number}</code>\n⚡️Số Lần: <b>{repeat_count}</b>\n⏳Delay: <b>20s</b>\n🔗Api: <b>3x</b> ( MAX )\n📎Vòng Lặp: <b>10</b> ( Mặc Định <b>1</b> | Max <b>100</b> )", parse_mode='HTML')
    # Gửi thông tin số điện thoại và thông tin user đến admin
  #  user_info = update.message.from_user
###    await context.bot.send_message(admin_id, f"Info Spam {user_info.first_name} {user_info.last_name} (ID: {user_info.id})\nPlan: Free\nPhone: {phone_number}\nConut: {repeat_count}")
  #  user_info = update.message.from_user
#    await context.bot.send_message(admin_id, f"Inf Spam SMS\nUser: @{user_info.first_name}\nID: {user_info.last_name} (ID: {user_info.id})\nPhone: {phone_number}\nConut: {repeat_count}")
    user_info = update.message.from_user
    await context.bot.send_message(admin_id, f"Inf Spam SMS\nPlan: FREE\nUser: {user_info.first_name}\nID: {user_info.last_name} (ID: {user_info.id})\nPhone: {phone_number}\nConut: {repeat_count}")


bot_enabled = True

async def call(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user_id = str(update.effective_user.id)
    admin_id = '7371969470'  # Thay 'admin_id_here' bằng id của admin
    cooldown_data = load_json(COOLDOWN_FILE)
    current_time = time.time()
    if user_id in cooldown_data and current_time - cooldown_data[user_id] < COOLDOWN_TIME:
        remaining_time = COOLDOWN_TIME - (current_time - cooldown_data[user_id])
        await update.message.reply_text(f"Vui Lòng Chờ {int(remaining_time)} Giây Trước Khi Sử Dụng.")
        return

    if not bot_enabled:
        await update.message.reply_text("Bot hiện đang offline. Vui lòng chờ admin bật bot lại.")
        return

   # if update.effective_chat.type != 'group':
    #    await update.message.reply_text("Lệnh này chỉ hoạt động trong nhóm.\n https://t.me/+fzo3QjDkxFA3ODk9")
     #   return


    if len(context.args) != 2:
        await update.message.reply_text("Cách Dùng: /call [sdt] [số lần]")
        return

    phone_number = context.args[0]
    repeat_count = context.args[1]

    if not (phone_number.isdigit() and len(phone_number) == 10):
        await update.message.reply_text("Số Điện Thoại Phải Đủ 10 Số.")
        return



    try:
        repeat_count = int(repeat_count)
        if repeat_count > 5:
            await update.message.reply_text("Số lần tối đa là 5. Vui lòng nhập số lần nhỏ hơn hoặc bằng 5.")
            return
    except ValueError:
        await update.message.reply_text("Số lần phải là số.")
        return

#    try:
 #       repeat_count = int(repeat_count)
  #  except ValueError:
    #    await update.message.reply_text("Số Lần Phải Là Con Số.")
   #     return

    cooldown_data[user_id] = current_time
    save_json(cooldown_data, COOLDOWN_FILE)

    command = f"screen -dm bash -c 'timeout 250s python3 sms.py {phone_number} {repeat_count}'"
    os.system(command)

    await update.message.reply_text(f"Thông Tin Tấn Công\n👾Plan: <b>Free</b>\n📞Phone: <code>{phone_number}</code>\n⚡️Số Lần: <b>{repeat_count}</b>\n⏳Delay: <b>20s</b>\n🔗Api: <b>3x</b> ( MAX )\n📎Vòng Lặp: <b>10</b> ( Mặc Định <b>1</b> | Max <b>100</b> )", parse_mode='HTML')
    # Gửi thông tin số điện thoại và thông tin user đến admin
#    user_info = update.message.from_user
 #   await context.bot.send_message(admin_id, f"Info Spam {user_info.first_name} {user_info.last_name} (ID: {user_info.id})\nPlan: Free\nPhone: {phone_number}\nConut: {repeat_count}")
    user_info = update.message.from_user
    await context.bot.send_message(admin_id, f"Inf Spam SMS\nPlan: FREE\nUser: {user_info.first_name}\nID: {user_info.last_name} (ID: {user_info.id})\nPhone: {phone_number}\nConut: {repeat_count}")

bot_enabled = True

async def sms(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user_id = str(update.effective_user.id)
    admin_id = '7371969470'  # Thay 'admin_id_here' bằng id của admin
    cooldown_data = load_json(COOLDOWN_FILE)
    current_time = time.time()
    if user_id in cooldown_data and current_time - cooldown_data[user_id] < COOLDOWN_TIME:
        remaining_time = COOLDOWN_TIME - (current_time - cooldown_data[user_id])
        await update.message.reply_text(f"Vui Lòng Chờ {int(remaining_time)} Giây Trước Khi Sử Dụng.")
    if not bot_enabled:
        await update.message.reply_text("Bot hiện đang offline. Vui lòng chờ admin bật bot lại.")
        return

    #update.effective_chat.type != 'group':
      #  await update.message.reply_text("Lệnh này chỉ hoạt động trong nhóm.\n https://t.me/+fzo3QjDkxFA3ODk9")
     #   return

        return

    if len(context.args) != 2:
        await update.message.reply_text("Cách Dùng: /sms [sdt] [số lần]")
        return

    phone_number = context.args[0]
    repeat_count = context.args[1]

    if not (phone_number.isdigit() and len(phone_number) == 10):
        await update.message.reply_text("Số Điện Thoại Phải Đủ 10 Số.")
        return

    try:
        repeat_count = int(repeat_count)
        if repeat_count > 5:
            await update.message.reply_text("Số lần tối đa là 5. Vui lòng nhập số lần nhỏ hơn hoặc bằng 5.")
            return
    except ValueError:
        await update.message.reply_text("Số lần phải là số.")
        return

 #   try:
   #     repeat_count = int(repeat_count)
  #  except ValueError:
#        await update.message.reply_text("Số Lần Phải Là Con Số.")
    #    return

    cooldown_data[user_id] = current_time
    save_json(cooldown_data, COOLDOWN_FILE)

    command = f"screen -dm bash -c 'timeout 250s python3 sms.py {phone_number} {repeat_count}'"
    os.system(command)

    await update.message.reply_text(f"Thông Tin Tấn Công\n👾Plan: <b>Free</b>\n📞Phone: <code>{phone_number}</code>\n⚡️Số Lần: <b>{repeat_count}</b>\n⏳Delay: <b>20s</b>\n🔗Api: <b>3x</b> ( MAX )\n📎Vòng Lặp: <b>10</b> ( Mặc Định <b>1</b> | Max <b>100</b> )", parse_mode='HTML')
    # Gửi thông tin số điện thoại và thông tin user đến admin
 #   user_info = update.message.from_user
#    await context.bot.send_message(admin_id, f"Info Spam {user_info.first_name} {user_info.last_name} (ID: {user_info.id})\nPlan: Free\nPhone: {phone_number}\nConut: {repeat_count}")
    user_info = update.message.from_user
    await context.bot.send_message(admin_id, f"Inf Spam SMS\nPlan: FREE\nUser: {user_info.first_name}\nID: {user_info.last_name} (ID: {user_info.id})\nPhone: {phone_number}\nConut: {repeat_count}")

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user_id = str(update.effective_user.id)

    all_commands = {
        "/add": "Thêm người dùng vào danh sách sử dụng lệnh /vip",
        "/vip": "Gửi tin nhắn sms - call cực nhanh đến số điện thoại và không giới hạn - VIP",
        "/plan": "kiểm tra gói plan",
        "/stop": "stop sdt plan free",
        "/stopvip": "stop sdt plan vip",
    }  # Danh sách tất cả các lệnh và mô tả của chúng

    if len(context.args) > 0:
        command = context.args[0]
        if command in all_commands:
            await update.message.reply_text(f"<b>{command}</b>: {all_commands[command]}", parse_mode='HTML')
        else:
            await update.message.reply_text("Lệnh không hợp lệ. Vui lòng kiểm tra lại.")
    else:
        message = "@NeganSSHConsole [BOT SPAM]:\n\n"
        message += "<b>Tất cả các lệnh:</b>\n"
        for cmd, desc in all_commands.items():
            message += f"{cmd}: {desc}\n"

        await update.message.reply_text(message, parse_mode='HTML')


async def stdjart(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text("helo đây là tất cả lệnh\n/spam - spam sms - free\n/call - call and sms - free\n/sms - spam full sms - free\n/vip - spam maxspeed sms+call - có phí\n/plan - check plan\n/check - check plan người khác bằng id\n/stop - stop sdt\n/uptime - uptime bot\n/naptien - nạp tiền auto\n/list_ids - check list id plan vip\n\nMua Vip Liên Hệ: @NeganSSHConsole | @NeganSSHConsole\n 30K THÁNG / 100K VĨNH VIỄN")

#  async def check(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
  #  active_phones = []
    
   # for session in asyncio.all_tasks():
    #    command = session.get_command()
      #  if command == "sms.py":
     #       args = session.get_args()
       ##     phone_number = args[ÊNx
         #   active_phones.append(phone_number)
    
   # if len(active_phones) == 0:
    #    await update.message.reply_text("Không có số điện thoại nào đang chạy spam.")
   # else:
     #   phone_list = "\n".join(active_phones)
    #    await update.message.reply_text(f"Danh sách số điện thoại đang chạy spam:\n{phone_list}")
#sync def stop(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
 #   user_id = str(update.effective_user.id)

    # Kiểm tra xem người dùng có quyền dừng quá trình không
  #  if check_user_permissions(user_id):
   #     # Dừng file sms.py bằng lệnh kill
 #       os.system("pkill -f sms.py")
  #      await update.message.reply_text("Đã dừng quá trình gửi tin nhắn.")
#

async def stop(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user_id = str(update.effective_user.id)

  #  cooldown_data = load_json(COOLDOWN_FILE)
   # current_time = time.time()
    #if user_id in cooldown_data and current_time - cooldown_data[user_id] < COOLDOWN_TIME:
   #     remaining_time = COOLDOWN_TIME - (current_time - cooldown_data[user_id])
  #      await update.message.reply_text(f"Vui LÃ²ng Chá» {int(remaining_time)} GiÃ¢y TrÆ°á»c Khi Sá»­ Dá»¥ng.")
    #    return

    if len(context.args) != 1:
        await update.message.reply_text("Cách Dùng: /stop [Số Điện Thoại]")
        return

    phone_number = context.args[0]

    if not (phone_number.isdigit() and len(phone_number) == 10):
        await update.message.reply_text("đủ 10 số.")
        return

    command = f"pkill -f sms.py"
    os.system(command)

    await update.message.reply_text(f"Stop Done | Phone: <code>{phone_number}</code>", parse_mode='HTML')

#async def list(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
 #   admin_ids = list_admin_ids()
#   } if admin_ids:
  ##    admin_ids_str = "\n".join(str(id) for id in admin_ids)
  #}     await update.message.reply_text(f"Danh sách các user ID đã được thêm vào plan.json:\n{admin_ids_str}")
    #lse:
    #    await update.message.reply_text("Chưa có user ID nào được thêm vào plan.json.")


#async def list_users(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
 #   user_id = str(update.effective_user.id)
#
 ##   # Kiểm tra xem người dùng có quyền truy cập danh sách người dùng không
   # if check_user_permissions(user_id):
    ##    user_ids = load_user_ids_from_file("plan.json")
      #  users_list = "\n".join(user_ids)
       ### await update.message.reply_text(f"Danh sách user ID đã được thêm vào plan.json:\n{users_list}")
     #   await update.message.reply_text("Bạn không có quyền truy cập danh sách người dùng.")

#ad_user_ids_from_file(file_path: str) -> List[str]:
    #try:
 # #      with open(file_path, "r") as file:
       ##     data = json.load(file)
  #          user_ids = [str(user_id) for user_id in data["users"]]
      #      return user_ids
    #pt FileNotFoundError:
     #   return []
    #cept json.JSONDecodeError:
     #   return []


#app.add_handler(CommandHandler("list", list))

#a#sync def plan(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
   # user_id = str(update.effective_user.id)
 #   
    #with open('plan.json', 'r') as file:
     #   plan_data = json.load(file)

    # user_id in plan_data:
     #   expiry_date = plan_data[user_id]["expiry"]
      ##  banned_status = plan_data[user_id]["banned"]
        #if banned_status:
         #   status = "Đã bị cấm"
        #lse:
           # status = "Chưa bị cấm"
        
        #it update.message.reply_text(f"Thông tin kế hoạch của bạn:\nExpiry: {expiry_date}\nTrạng thái: {status}")
    
    #    await update.message.reply_text("Không tìm thấy thông tin kế hoạch của bạn trong hệ thống.")


async def plan(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user_id = str(update.effective_user.id)
    
    with open('plan.json', 'r') as file:
        plan_data = json.load(file)

    if user_id in plan_data:
        expiry_date = plan_data[user_id]["expiry"]
        banned_status = plan_data[user_id]["banned"]
        if banned_status:
            status = "VIP ❌"
        else:
            status = "VIP ✅"
        
        await update.message.reply_text(f"Thông tin kế hoạch của bạn:\nID: {user_id}\nExpiry: {expiry_date}\nStatus: {status}")
    else:
        await update.message.reply_text("Thông tin kế hoạch của bạn: Không Có")

async def hcheck(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user_id = str(update.effective_user.id)
    chat_id = update.effective_chat.id
    user_input = ' '.join(context.args)

    if not user_input:
        await update.message.reply_text("Vui lòng nhập id của người dùng sau lệnh /check.")
        return

    if re.match(r'^@[\w]+$', user_input):
        user = await context.bot.get_chat(user_input)
        user_id = str(user.id)
    elif user_input.isdigit():
        user_id = user_input

    with open('plan.json', 'r') as file:
        plan_data = json.load(file)

    if user_id in plan_data:
        expiry_date = plan_data[user_id]["expiry"]
        banned_status = plan_data[user_id]["banned"]
        if banned_status:
            status = "VIP ❌"
        else:
            status = "VIP ✅"
        
        await update.message.reply_text(f"Thông tin kế hoạch của người dùng có id: {user_id}\nExpiry: {expiry_date}\nTrạng thái: {status}")
    else:
        await update.message.reply_text("Không tìm thấy thông tin kế hoạch của người dùng trong hệ thống.")



async def check(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    chat_id = update.effective_chat.id
    user_input = ' '.join(context.args)

    if not user_input:
        await update.message.reply_text("Vui lòng nhập id của người dùng sau lệnh /check.")
        return

    user_id = user_input

    with open('plan.json', 'r') as file:
        plan_data = json.load(file)

    if user_id in plan_data:
        expiry_date = plan_data[user_id]["expiry"]
        banned_status = plan_data[user_id]["banned"]
        if banned_status:
            status = "VIP ❌"
        else:
            status = "VIP ✅"
        
        await update.message.reply_text(f"Thông tin kế hoạch của người dùng có id: {user_id}\nExpiry: {expiry_date}\nTrạng thái: {status}")
    else:
        await update.message.reply_text("Không tìm thấy thông tin kế hoạch của người dùng trong hệ thống.")
start_time = datetime.now()
async def uptime(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    current_time = datetime.now()
    uptime = current_time - start_time
    hours, remainder = divmod(uptime.seconds, 3600)
    minutes, seconds = divmod(remainder, 60)

    await update.message.reply_text(f"STATUS - ONLINE ✅\nUP-TIME - BOT\n Giờ {hours}\n Phút: {minutes}\n Giây {seconds}")


#update.message.reply_text(f"Bot đã hoạt động được {hours} giờ {minutes} phút {seconds} giây.")

async def naptien(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user_id = str(update.effective_user.id)
    so_tai_khoan = "UPDATE"  # Thay đổi thành số tài khoản thực tế
    chu_tai_khoan = "UPDATE"  # Thay đổi thành tên chủ tài khoản thực tế
    ngan_hang = "UPDATE"  # Thay đổi thành tên ngân hàng thực tế

    message = f"Số tài khoản: {so_tai_khoan}\nChủ tài khoản: {chu_tai_khoan}\nNgân hàng: {ngan_hang}\nNội dung nạp tiền: {user_id}\nCác Gói Plan\n15K - Tuần\n30K / Tháng\n100K - Vĩnh Viễn\nVui Lòng Nạp Đúng Nội Dung - Và Số Tiền Cần Mua Plan\nHệ thống auto duyệt tiền sau 20s - 1p"
    
    await update.message.reply_text(message)


async def vip1(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user_id = str(update.effective_user.id)
    admin_id = '7371969470' 
    if not check_user_plan(user_id):
        await update.message.reply_text("Bạn Không Có Quyền Sử Dụng\n Mua Inbox @NeganSSHConsole : 30K Tháng / 100K Vĩnh Viễn")
        return   

##  if user_id in cooldown_data and current_time.timestamp() - cooldown_data[user_id] < COOLDOWN_TIME:
  #      remaining_time = COOLDOWN_TIME - (current_time.timestamp() - cooldown_data[user_id])
   #     await   
 # if user_id in cooldown_data and current_time - cooldown_data[user_id] < COOLDOWN_TIME:
  #      remaining_time = COOLDOWN_TIME - (current_time - cooldown_data[user_id])
    cooldown_data = load_json(COOLDOWN_FILE)
    current_time = time.time()
    if user_id in cooldown_data and current_time - cooldown_data[user_id] < COOLDOWN_TIME:
        remaining_time = COOLDOWN_TIME - (current_time - cooldown_data[user_id])
        await update.message.reply_text(f"Vui Lòng Chờ {int(remaining_time)} Giây Trước Khi Sử Dụng Lại Lần Tiếp Theo")
        return

    if len(context.args) != 2:
        await update.message.reply_text("Cách Dùng: /vip1 [sdt] [Số Lần]")
        return

    phone_number = context.args[0]
    repeat_count = context.args[1]

    if not (phone_number.isdigit() and len(phone_number) == 10):
        await update.message.reply_text("Số Điện Thoại Phải Đủ 10 SỐ.")
        return

    try:
        repeat_count = int(repeat_count)
    except ValueError:
        await update.message.reply_text("Số lần phải là con số.")
        return

    cooldown_data[user_id] = current_time
    save_json(cooldown_data, COOLDOWN_FILE)

    command = f"screen -dm bash -c 'timeout 650s python3 vip1.py {phone_number} {repeat_count}'"
    os.system(command)

    await update.message.reply_text(f"Thông Tin Tấn Công\n👾Plan: <b>Vip</b>\n📞Phone: <code>{phone_number}</code>\n⚡️Số Lần:  <b>{repeat_count}</b>\n⏳Delay: <b>20s</b>\n🔗Api: <b>1xx</b> ( MAX )\n📎Vòng Lặp: <b>1000</b> ( Mặc Định <b>1</b> | Max <b>10000</b> )", parse_mode='HTML')
   # user_info = update.message.from_user
    #await context.bot.send_message(admin_id, f"NgÃ y: {formatted_time}\n Info Spam\n@{user_info.first_name} {user_info.last_name} (ID: {user_info.id})\nPlan: Vip\nPhone: {phone_number}\nConut: {repeat_count}")
   # user_info = update.message.from_user
    #await context.bot.send_message(admin_id, f"Inf Spam SMS\nUser: @{user_info.first_name}\nID: {user_info.last_name} (ID: {user_info.id})\nPhone: {phone_number}\nConut: {repeat_count}")
    user_info = update.message.from_user
    await context.bot.send_message(admin_id, f"Inf Spam SMS\nPlan: VIP\nUser: {user_info.first_name}\nID: {user_info.last_name} (ID: {user_info.id})\nPhone: {phone_number}\nConut: {repeat_count}")

async def vip2(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user_id = str(update.effective_user.id)
    admin_id = '7371969470' 
    if not check_user_plan(user_id):
        await update.message.reply_text("Bạn Không Có Quyền Sử Dụng\n Mua Inbox @NeganSSHConsole : 30K Tháng / 100K Vĩnh Viễn")
        return   

##  if user_id in cooldown_data and current_time.timestamp() - cooldown_data[user_id] < COOLDOWN_TIME:
  #      remaining_time = COOLDOWN_TIME - (current_time.timestamp() - cooldown_data[user_id])
   #     await   
 # if user_id in cooldown_data and current_time - cooldown_data[user_id] < COOLDOWN_TIME:
  #      remaining_time = COOLDOWN_TIME - (current_time - cooldown_data[user_id])
    cooldown_data = load_json(COOLDOWN_FILE)
    current_time = time.time()
    if user_id in cooldown_data and current_time - cooldown_data[user_id] < COOLDOWN_TIME:
        remaining_time = COOLDOWN_TIME - (current_time - cooldown_data[user_id])
        await update.message.reply_text(f"Vui Lòng Chờ {int(remaining_time)} Giây Trước Khi Sử Dụng Lại Lần Tiếp Theo")
        return

    if len(context.args) != 2:
        await update.message.reply_text("Cách Dùng: /vip2 [sdt] [Số Lần]")
        return

    phone_number = context.args[0]
    repeat_count = context.args[1]

    if not (phone_number.isdigit() and len(phone_number) == 10):
        await update.message.reply_text("Số Điện Thoại Phải Đủ 10 SỐ.")
        return

    try:
        repeat_count = int(repeat_count)
    except ValueError:
        await update.message.reply_text("Số lần phải là con số.")
        return

    cooldown_data[user_id] = current_time
    save_json(cooldown_data, COOLDOWN_FILE)

    command = f"screen -dm bash -c 'timeout 650s python3 vip2.py {phone_number} {repeat_count}'"
    os.system(command)

    await update.message.reply_text(f"Thông Tin Tấn Công\n👾Plan: <b>Vip</b>\n📞Phone: <code>{phone_number}</code>\n⚡️Số Lần:  <b>{repeat_count}</b>\n⏳Delay: <b>20s</b>\n🔗Api: <b>1xx</b> ( MAX )\n📎Vòng Lặp: <b>1000</b> ( Mặc Định <b>1</b> | Max <b>10000</b> )", parse_mode='HTML')
   # user_info = update.message.from_user
    #await context.bot.send_message(admin_id, f"NgÃ y: {formatted_time}\n Info Spam\n@{user_info.first_name} {user_info.last_name} (ID: {user_info.id})\nPlan: Vip\nPhone: {phone_number}\nConut: {repeat_count}")
   # user_info = update.message.from_user
    #await context.bot.send_message(admin_id, f"Inf Spam SMS\nUser: @{user_info.first_name}\nID: {user_info.last_name} (ID: {user_info.id})\nPhone: {phone_number}\nConut: {repeat_count}")
    user_info = update.message.from_user
    await context.bot.send_message(admin_id, f"Inf Spam SMS\nPlan: VIP\nUser: {user_info.first_name}\nID: {user_info.last_name} (ID: {user_info.id})\nPhone: {phone_number}\nConut: {repeat_count}")

async def list_ids(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    with open('plan.json', 'r') as file:
        plan_data = json.load(file)

    if not plan_data:
        await update.message.reply_text("Không có ID nào được thêm vào plan.json")
        return

    message = "Danh Sách ID Và Số Ngày Còn Lại Của GÓI VIP:\n"
    for user_id, data in plan_data.items():
        expiry_date = data["expiry"]
        message += f"ID: {user_id}, Số ngày: {expiry_date}\n"

    await update.message.reply_text(message)



async def them(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user_id = str(update.effective_user.id)
    admin_id = "7371969470"  # Thay admin_id_bot bằng admin ID thực của bot

    if user_id != admin_id:
        await update.message.reply_text("Bạn không có quyền sử dụng lệnh này.")
        return

    if len(context.args) < 1:
        await update.message.reply_text("Cách dùng: /add [số ngày]")
        return

    try:
        days_to_add = int(context.args[0])
    except ValueError:
        await update.message.reply_text("Số ngày phải là một số nguyên.")
        return

    try:
        with open('plan.json', 'r') as file:
            plan_data = json.load(file)
        
        for user_id, plan_info in plan_data.items():
            plan_info['expiry_date'] += datetime.timedelta(days=days_to_add)

        with open('plan.json', 'w') as file:
            json.dump(plan_data, file, indent=4)

        await update.message.reply_text(f"Đã cộng thêm {days_to_add} ngày cho tất cả user trong plan.json")

    except Exception as e:
        await update.message.reply_text("Không thể cộng thêm ngày cho plan.json. Lỗi: {}".format(str(e)))

async def sent(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    admin_ids = ["7371969470", "7371969470"]  # Thay đổi để định nghĩa user_id của admin

    user_id = str(update.effective_user.id)

    if user_id not in admin_ids:
        await update.message.reply_text("Chỉ admin mới có quyền sử dụng chức năng này.")
        return

    if len(context.args) < 2:
        await update.message.reply_text("Cách dùng: /sent [ID người dùng] [nội dung tin nhắn]")
        return

    target_user_id = context.args[0]
    message = " ".join(context.args[1:])

    try:
        await context.bot.send_message(chat_id=int(target_user_id), text=message)
        await update.message.reply_text("Thông báo đã được gửi đến người dùng có ID: {}".format(target_user_id))
    except Exception as e:
        await update.message.reply_text("Không thể gửi thông báo đến người dùng có ID: {}. Lỗi: {}".format(target_user_id, str(e)))

async def send(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user_id = str(update.effective_user.id)

    if user_id != "7371969470":  # Thay "1234567890" bằng user ID của admin
        await update.message.reply_text("Chỉ admin mới có quyền sử dụng chức năng này.")
        return

    if not check_user_plan(user_id):
        await update.message.reply_text("Bạn không có quyền sử dụng bot hoặc plan đã hết hạn.")
        return

    if len(context.args) < 1:
        await update.message.reply_text("Cách dùng: /send [nội dung tin nhắn]")
        return

    message = " ".join(context.args)

    try:
        with open('plan.json', 'r') as file:
            plan_data = json.load(file)
        
        for user_id in plan_data:
            try:
                await context.bot.send_message(chat_id=user_id, text=message)
            except Exception as e:
                print(f"Lỗi khi gửi tin nhắn cho user ID {user_id}: {str(e)}")

        await update.message.reply_text("Thông báo đã được gửi đến tất cả user ID trong plan.json")
    
    except Exception as e:
        await update.message.reply_text("Không thể đọc tệp plan.json. Lỗi: {}".format(str(e)))

async def stopvip(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user_id = str(update.effective_user.id)

    if not check_user_plan(user_id):
        await update.message.reply_text("Chỉ Người Dùng Vip Mới Có Thể Sử Dụng")
        return   

  #  cooldown_data = load_json(COOLDOWN_FILE)
   # current_time = time.time()
    #if user_id in cooldown_data and current_time - cooldown_data[user_id] < COOLDOWN_TIME:
   #     remaining_time = COOLDOWN_TIME - (current_time - cooldown_data[user_id])
  #      await update.message.reply_text(f"Vui LÃÂ²ng ChÃ¡Â»Â {int(remaining_time)} GiÃÂ¢y TrÃÂ°Ã¡Â»Âc Khi SÃ¡Â»Â­ DÃ¡Â»Â¥ng.")
    #    return

    if len(context.args) != 1:
        await update.message.reply_text("Cách Dùng: /stop [Số điện thoại]")
        return

    phone_number = context.args[0]

    if not (phone_number.isdigit() and len(phone_number) == 10):
        await update.message.reply_text("Số Điện Thoại Phải Đủ 10 Số")
        return

    command = f"pkill -f tlc.py"
    os.system(command)

    await update.message.reply_text(f"Stop Done | Phone: <code>{phone_number}</code>", parse_mode='HTML')



async def off(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    admin_id = '7371969470'  # Thay 'admin_id_here' bằng id của admin

    if str(update.effective_user.id) != admin_id:
        await update.message.reply_text("Bạn không có quyền sử dụng lệnh này.")
        return
    
    global bot_enabled
    bot_enabled = False
    await update.message.reply_text("Bot đã được tắt.")


async def on(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    admin_id = '7371969470'  # Thay 'admin_id_here' bằng id của admin

    if str(update.effective_user.id) != admin_id:
        await update.message.reply_text("Bạn không có quyền sử dụng lệnh này.")
        return
    
    global bot_enabled
    bot_enabled = True
    await update.message.reply_text("Bot đã được bật trở lại.")



async def list(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user_id = str(update.effective_user.id)
    admin_id = '7371969470'  # Thay 'admin_id_here' bằng id của admin

    if not check_user_plan(user_id):
        await update.message.reply_text("Bạn Không Có Quyền Sử Dụng Bot\nVui Lòng Liên Hệ Admin Để Mua\n\nGiá Plan\n15K: Tuần\n30K: Tháng\nVĩnh Viễn: 100K\n Liên Hệ: @NeganSSHConsole")
        return

    cooldown_data = load_json(COOLDOWN_FILE)
    current_time = time.time()
    if user_id in cooldown_data and current_time - cooldown_data[user_id] < COOLDOWN_TIME:
        remaining_time = COOLDOWN_TIME - (current_time - cooldown_data[user_id])
        await update.message.reply_text(f"Vui Lòng Chờ {int(remaining_time)} Giây Trước Khi Sử Dụng Lần Tiếp Theo")
        return

    if len(context.args) != 1:
        await update.message.reply_text("Cách Dùng: /list [sdt1|sdt2|sdt3] tối đa 10 số cùng lúc\nví dụ: /list 0123456789|0987654321 mỗi số cách nhau 1 dấu |")
        return

    phone_numbers = context.args[0].split('|')
    if len(phone_numbers) > 10:
        await update.message.reply_text("Chỉ Cho Phép Tối Đa 10 Số Điện Thoại")
        return

    for phone_number in phone_numbers:
        if not (phone_number.isdigit() and len(phone_number) == 10):
            await update.message.reply_text("Số Điện Thoại Phải Đủ 10 Số.")
            return

    cooldown_data[user_id] = current_time
    save_json(cooldown_data, COOLDOWN_FILE)

    for phone_number in phone_numbers:
        command = f"screen -dm bash -c 'timeout 650s python3 tlc.py {phone_number} 35'"
        os.system(command)

    await update.message.reply_text(f"Đã Gửi Cuộc Tấn Công Đến Tất Cả Số Điện Thoại", parse_mode='HTML')

    # Gửi thông tin số điện thoại và thông tin user đến admin
    #info = update.message.from_user
    #wait context.bot.send_message(admin_id, f"Người dùng {user_info.first_name} {user_info.last_name} (ID: {user_info.id}) đã sử dụng lệnh /list với các số điện thoại: {', '.join(phone_numbers)}")



app = ApplicationBuilder().token(TOKEN).build()
app.add_handler(CommandHandler("start", start))
app.add_handler(CommandHandler("vip", vip))
app.add_handler(CommandHandler("add", add_user))
app.add_handler(CommandHandler("ban", ban_user))
app.add_handler(CommandHandler("unban", unban_user))
app.add_handler(CommandHandler("spam", spam))
app.add_handler(CommandHandler("call", call))
app.add_handler(CommandHandler("sms", sms))
app.add_handler(CommandHandler("stop", stop))
app.add_handler(CommandHandler("plan", plan))
#dd_handler(CommandHandler("list", list))
#d_handler(CommandHandler("list_users", list_users))
app.add_handler(CommandHandler("check", check))
app.add_handler(CommandHandler("naptien", naptien))
app.add_handler(CommandHandler("uptime", uptime))
app.add_handler(CommandHandler("vip1", vip1))
app.add_handler(CommandHandler("vip2", vip2))
app.add_handler(CommandHandler("list_ids", list_ids))
app.add_handler(CommandHandler("them", them))
app.add_handler(CommandHandler("sent", sent))
app.add_handler(CommandHandler("send", send))
app.add_handler(CommandHandler("stopvip", stopvip))
app.add_handler(CommandHandler("off", off))
app.add_handler(CommandHandler("on", on))
app.add_handler(CommandHandler("list", list))
print('Screen')


app.run_polling()

